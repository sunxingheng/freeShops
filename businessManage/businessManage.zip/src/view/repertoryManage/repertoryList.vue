<template>

</template>

<script>
    export default {
        name: "repertoryList"
    }
</script>

<style scoped>

</style>
