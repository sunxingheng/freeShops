<template>

</template>

<script>
    export default {
        name: "goodsList"
    }
</script>

<style scoped>

</style>
